package com.arto.arto.domain.artwork_tags.entity;

public class ArtworkTagsEntity {
}
