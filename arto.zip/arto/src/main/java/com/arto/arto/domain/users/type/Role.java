package com.arto.arto.domain.users.type;

// 사용자 역할을 정의하는 Enum
public enum Role {
    USER, ADMIN
}