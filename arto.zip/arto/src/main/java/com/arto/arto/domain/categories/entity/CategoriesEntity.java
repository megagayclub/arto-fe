package com.arto.arto.domain.categories.entity;

public class CategoriesEntity {
}
